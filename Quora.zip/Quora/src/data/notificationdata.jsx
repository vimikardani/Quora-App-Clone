
// Data for notifications
export const notifications = [
    {
        id: 1,
        notificationimage:"https://qph.cf2.quoracdn.net/main-thumb-ti-1621146-100-iunpcrjywkofgcmfktipuiuarvhuqmxw.jpeg",
        notificationtitle: "Financial Update",
        releasedate:"Octomber 21",
        info: "How do you spend your monthly salary? I earn INR 70,000 per month. I live in Pune, not really cheap city."

    },
    {
        id: 2,
        notificationimage:"https://qph.fs.quoracdn.net/main-thumb-t-930-100-cbbsbwijdhpyzlpipejvqpiijhhoaday.jpeg",
        notificationtitle: "What are some of the most famous unsolved mysteries? What are some of the most famous unsolved mysteries?",
        releasedate:"Octomber 1",
        info: "That of Palmina Martinelli. She was burned alive at 14 because she didn't want to prostitute herself."

    },
    {
        id: 2,
        notificationimage:"https://qph.cf2.quoracdn.net/main-thumb-ti-1618451-100-bjajmubyaledvedkyjisjtnkljwadmzq.jpeg",
        notificationtitle: "Human mind and readers",
        releasedate:"Octomber 18",
        info: "RULES TO TEACH YOUR SON"

    },
    {
        id: 2,
        notificationimage:"https://qph.fs.quoracdn.net/main-thumb-t-801-100-Sf8h894FXbQZQit0TeqDrrqS6xw6dwCQ.jpeg",
        notificationtitle: "",
        releasedate:"Octomber 18",
        info: "Congretulations,Your answer had 4.224 views in the past week! "

    },
    
]
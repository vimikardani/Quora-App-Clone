// data for space
export const spaces = [
    {
        id: 1,
        image:"https://qph.cf2.quoracdn.net/main-thumb-t-785-100-SPdel3dlJbwe69kzHRdC9zraBLeasYX0.jpeg",
        title: "The Programmers cafe",
        description: "The space to share idea via Coding"

    },
    {
        id: 2,
        image:"https://qph.cf2.quoracdn.net/main-thumb-t-1513-100-ktlxdyfyihixtydnlisznwdcywqmteyp.jpeg",
        title: "Programming Algorithms",
        description: "All about the programming data structure and algorithms, let's learn.."

    },
    {
        id: 3,
        image:"https://qph.cf2.quoracdn.net/main-thumb-t-19481-100-qkjzcnkbeqhkfxzqulsnfnkxcwebdqws.jpeg",
        title: "Python and ML Basics",
        description: "Basics concepts of python and Machine Learning for Beginners"

    },
    {
        id: 4,
        image:"https://qph.cf2.quoracdn.net/main-thumb-t-6466-100-kFicxKIQ4QAkRdD4Z7spmGaORM8GeLHi.jpeg",
        title: "Data Analytics Basics",
        description: "Bussiness- Statistics| Statistical=Modelling|Analytics-Tools"
        },
    {
        id: 5,
        image:"https://qph.cf2.quoracdn.net/main-thumb-t-7159-100-vsnghaharbpvuobjoxdxslkcmdlpgrxt.jpeg",
        title: "VLSI Beginners",
        description: "Discuss & Share idea,jobs,career Tips for VLSI Beginners"

    },
    {
        id: 6,
        image:"https://qph.cf2.quoracdn.net/main-thumb-t-15617-100-ulllewvqfhlioqourfyztjoonpuluolb.jpeg",
        title: "The Internships Club",
        description: "Join this space to get daily updates & info on Internship's Advise"

    },
    {
        id: 7,
        image:"https://qph.cf2.quoracdn.net/main-thumb-t-8120-100-z7mHZcGoK97W0j7KPvH0DCDpmcJPbDO9.jpeg",
        title: "Prpgrammer's Heaven",
        description: "It's all about Computer Programming"

    },
    {
        id: 8,
        image:"https://qph.cf2.quoracdn.net/main-thumb-t-2307-100-tgwpfzgzdpnbkxjhrhzjzisqgaazhuxl.jpeg",
        title: "AI-Cybersecurity-Hacking",
        description: "IBringing Humans closer to Machines"

    }
]
//  data for Post box
export const posts = [
    {
      number: 1,
      image: "https://qph.cf2.quoracdn.net/main-thumb-409901607-50-yrflsgvwxfmbwbrjbqtvgqwbfzvdoufu.jpeg",
      author: "Minal Ahuja",
      position: "MTS at Salesforse | ex-Wipro,Adobe,Freshworks",
      date: "Updated Mar 27",
      posttitle: "How do i improve coding in 3 months?",
      postinfo: "Hello , I think I’m the perfect candidate to answer this question.Let me take you back in November 2021. The month I was first introduced to DSA :) I was always wondering how people gets job in FAANG or Product companies. Little me, always thought I know DSA because we all studied this in college.But that month changed everything for me, I started my DSA journey and here I’m sharing my experience.",
      postimage: "https://qph.cf2.quoracdn.net/main-qimg-e91f16859e1397a12d87aa6e006a7b54",
      comment:370,
      share:75
      

    },
    {
        number: 2,
        image: "https://qph.cf2.quoracdn.net/main-thumb-281068371-200-wfzrmdhuefintqvgqgyirugbvjjtblmu.jpeg",
        author: "Balaji Jagannathan",
        position: "Probationary officer 2021–present",
        date: "Updated July 7",
        posttitle: "What is life without a job?",
        postinfo: "I think I am eligible to answer this question since I was jobless for more than four years.First, finished engineering fron a third grade college with more than 80 percent and a 9k worth job, but I didn't get to join as the company asked only a few to join immediately and others lately and that turned out to be a good thing for me as the job was very tough.Decided to look for jobs that can pay well and I can get easily and banking was the one I chose.",
        postimage: "https://qph.cf2.quoracdn.net/main-qimg-e1038b6dbb84394c7c49232d46dafeee-lq",
        
        comment:480,
        share:50
        
  
      },
      {
      number: 3,
        image: "https://qph.cf2.quoracdn.net/main-thumb-5309569-50-kjhxcfdqxtdnomnjnlmkbgpprjqcfryu.jpeg",
        author: "Ashish Gambhir",
        position: "Studied at Netaji Subhas Institute of Technology",
        date: "Updated 10 May",
        posttitle: "What is the first thing you did with your salary?",
        postinfo: "I was placed in Qualcomm. The package was good, but the joining bonus was simply phenomenal.First salary, 2lac in the account, no girlfriend or wife. So what do you do?I booked a trip to Europe for my parents.",
        postimage: "https://qph.cf2.quoracdn.net/main-qimg-44c455ece8b4be4ff9d32c21cae9a545.webp",
        
        comment:305,
        share:113
        
      }
  ]


  

import { BrowserRouter, Routes, Route } from "react-router-dom";
import Main from "./components/main/Main"
import Notification from "./components/notification/Notification";
import Login from "./components/login/Login";
import Registration from "./components/registartion/Registration";

 

const App = () => {
  
  return (
    <>
    {/* set all routes */}
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Main/>}/>
      <Route path="notification" element={<Notification/>}/>
      <Route path="login" element={<Login/>}/>
      <Route path="registration" element={<Registration/>}/>
    </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
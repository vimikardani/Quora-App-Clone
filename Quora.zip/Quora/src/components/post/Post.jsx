import React from 'react';
import './post.css';
import { posts } from '../../data/postdata';
import Postcard from '../post-card/Postcard';


const Post = () => {
  
  return (
    // UI for Post area
    <>
      <section>
        <div className='q-box'>
          <div className='row1'>
            <div className="element1">
              <svg className='usericon' xmlns="http://www.w3.org/2000/svg" width="30" height="30 " fill="gray" class="bi bi-person-plus" viewBox="0 0 16 16">
                <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z" />
              </svg>
            </div>
            <div className='element2'>
              <input className='userinput' type='text' placeholder='What do you want to ask or share?'></input>
            </div>
          </div>
          <div className="element3">
            <div className="q-boxicon">
              <svg className='' width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><g class="icon_svg-stroke" stroke="#666" stroke-width="1.5" fill="none" fill-rule="evenodd"><g transform="translate(9 7)"><path d="M3 6v-.5A2.5 2.5 0 1 0 .5 3" stroke-linecap="round" stroke-linejoin="round"></path><circle class="icon_svg-fill_as_stroke" fill="#666" cx="3" cy="8.5" r="1" stroke="none"></circle></g><path d="M7.5 4h9a3 3 0 0 1 3 3v9a3 3 0 0 1-3 3h-3L9 22v-3H7.5a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3Z" stroke-linejoin="round"></path></g></svg>
              <span className='q-boxtext'>Ask</span>
              <span className='border'></span>
            </div>
            <div className='q-boxicon'>
              <svg className='' width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><g stroke-width="1.5" fill="none" fill-rule="evenodd"><path d="M18.571 5.429h0a2 2 0 0 1 0 2.828l-9.9 9.9-4.24 1.416 1.412-4.245 9.9-9.9h0a2 2 0 0 1 2.828 0Z" class="icon_svg-stroke" stroke="#666" stroke-linecap="round" stroke-linejoin="round"></path><path class="icon_svg-fill_as_stroke" fill="#666" d="m4.429 19.571 2.652-.884-1.768-1.768z"></path><path d="M14.5 19.5h5v-5m-10-10h-5v5" class="icon_svg-stroke" stroke="#666" stroke-linecap="round" stroke-linejoin="round"></path></g></svg>
              <span className='q-boxtext'>Answer</span>
              <span className='border'></span>
            </div>
            <div className="q-boxicon">
              <svg className='' width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><path d="M18.571 5.429h0a2 2 0 0 1 0 2.828l-9.9 9.9-4.24 1.416 1.412-4.245 9.9-9.9a2 2 0 0 1 2.828 0Z" class="icon_svg-stroke" stroke="#666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path class="icon_svg-fill_as_stroke" fill="#666" d="m4.429 19.571 2.652-.884-1.768-1.768z"></path></g></svg>
              <span className='q-boxtext'>Post</span>

            </div>
          </div>
        </div>
        
        {/* Map data from Pasocard components */}
        {
          posts.map((data)=>{
            return <Postcard 
            image={data.image} 
            author={data.author}
            position={data.position}
            date={data.date}
            posttitle={data.posttitle}
            postinfo={data.postinfo}
            postimage={data.postimage}
            comment={data.comment}
            share={data.share}
            />

          })
        }
      </section>
    </>
  )

}

export default Post
import React from 'react';
import './spacecard.css';

const Spacecard = ({ image, title, description }) => {
    return (
        <>
            <div className="space-box">
                <div className="space-image">
                    <img className='space-image' src={image}></img>
                </div>
                <div className="space-detail">
                    <span className='title'>{title}</span><br></br>
                    <span className='description'>
                        {description}
                    </span>
                    
                </div>
            </div>
        </>
    )
}

export default Spacecard
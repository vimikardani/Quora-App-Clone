import React from 'react';
import './notificationcard.css';
 
//get props data from notificationdata components 
const Notificationcard = ({notificationimage,notificationtitle,releasedate,info}) => {
    
  return (
    // notiocation box UI
    <>
    <div className="notification-info">
        <div className="notification-box" id='notification_box'>
            
                <div className="user-image">
                    <img className='user-profile' src={notificationimage}></img>
                </div>
                <div className="notification-detail">
                    <div className="notification-title-info">
                    <span className='notification-title'>{notificationtitle}</span>
                    <span  className='noti-card-dot'></span>
                    <span className='release-date'>{releasedate}</span>
                    </div>
                    <div className='notification-description'>{info}
                    </div>
                    
                </div>
                <div className="notification-dot-right">
                    <div className="dot-right"></div>
                    <div className="dot-right"></div>
                    <div className="dot-right"></div>
                </div>
                
            </div>
        </div>
    </>
  )
}

export default Notificationcard
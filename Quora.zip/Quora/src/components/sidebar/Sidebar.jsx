import React from 'react';
import './sidebar.css';

const Sidebar = () => {
  return (
    // Sidebar UI
    <>
      <section>
        <div className='qSidebar'>
          <div className='createspace'>
            <svg className='plusIcon' xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-lg" viewBox="0 0 16 16">
              <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z" />
            </svg>
            <p className='p-text'>Create<br></br> Spaces</p>
          </div>
          <div className="sidebarOptions">
            <div className="sidebarOption">
              <img className='' src="https://qph.fs.quoracdn.net/main-thumb-t-930-100-cbbsbwijdhpyzlpipejvqpiijhhoaday.jpeg" alt="History" />
              <span className='activeicon'></span>
              <p className='option_title'>History</p>
            </div>

            <div className="sidebarOption">
              <img src="https://qph.fs.quoracdn.net/main-thumb-t-858-100-VnZbEVtOIGkEHXlnYId9slumV59IPgkA.jpeg" alt="Business" />
              <span className='activeicon'></span>
              <p className='option_title'>Business</p>
            </div>

            <div className="sidebarOption">
              <img src="https://qph.fs.quoracdn.net/main-thumb-t-801-100-Sf8h894FXbQZQit0TeqDrrqS6xw6dwCQ.jpeg" alt="" />
              <span className='activeicon'></span>
              <p className='option_title'>Music</p>
            </div>

            <div className="sidebarOption">
              <img src="https://qph.fs.quoracdn.net/main-thumb-t-931-100-c8WCPwZ9qPsh5zLGQ5wHh1ddxtc9Cch7.jpeg" alt="" />
              <span className='activeicon'></span>
              <p className='option_title'>Science</p>
            </div>

            <div className="sidebarOption">
              <img src="https://qph.fs.quoracdn.net/main-thumb-t-1140-100-24q3tiv4WhPssc5TGwf0mvCM5aiqGVXW.jpeg" alt="" />
              <span className='activeicon'></span>
              <p className='option_title'>Health</p>
            </div>

            <div className="sidebarOption">
              <img src="https://qph.fs.quoracdn.net/main-thumb-t-843-100-W7FzODceTO2aQmp8D7E4rKZ8YgSv21eR.jpeg" alt="" />
              <span className='activeicon'></span>
              <p className='option_title'>Movies</p>
            </div>

            <div className="sidebarOption">
              <img src="https://qph.fs.quoracdn.net/main-thumb-t-2177-100-JiR07D1TQSfeQzRvWXomVaY4Poj2f8Yb.jpeg" alt="" />
              <span className='activeicon'></span>
              <p className='option_title'>Technology</p>
            </div>

            <div className="sidebarOption">
              <img src="https://qph.fs.quoracdn.net/main-thumb-t-996-100-bfZBQjeEenKKl8fcNY4tVv0FyArtB0Mb.jpeg" alt="" />
              <span className='activeicon'></span>
              <p className='option_title'>Education</p>
            </div>

          </div>
          <div className='links'>
            <a href='#'>about .</a>
            <a href='#'>Careers .</a><br></br>
            <a href='#'>Terms .</a>
            <a href='#'>Privacy .</a><br></br>
            <a href='#'>Accetable use .</a><br></br>
            <a href='#'>Bussiness .</a>
            <a href='#'>Press .</a><br></br>
            <a href='#'>Your Ad Choices .</a>
            
          </div>
        </div>
      </section>
    </>
  )
}

export default Sidebar
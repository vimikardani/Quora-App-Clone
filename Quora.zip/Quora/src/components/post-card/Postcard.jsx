import React from 'react';
import { useState } from 'react';
import './postcard.css';

// get props data from postdata
const Postcard = ({ image, author, position, date, posttitle, postinfo, postimage, comment, share }) => {

  // usestate for upvote ad downvote counter
  const [vote, setvote] = useState(1);


  return (
    // Post box UI
    <>
      <div className='post-box'>
        <div className="post-box-header">
          <div className="author-profile">
            <img className='profile-img' src={image}></img>
          </div>
          <div className="author-name">
            <span className='author'>{author}</span>
          </div>
          <div>
            <span className='dot-post-header'></span>
          </div>
          <div className="follow-post">
            <span className='follow'>Follow</span>
          </div>
        </div>
        <div className="post-box-info">
          <div className="author-position">
            <span className='position'>
              {position}
            </span>
          </div>
          <div>
            <span className='dot-post-info'></span>
          </div>
          <div className="post-date">
            <span className='date'>{date}</span>
          </div>
        </div>
        <div className="post-box-details">
          <div className="post-details">
            <span className='post-title'>
              {posttitle}
            </span>
            <p className='post-info'>
              {postinfo}
            </p>
          </div>
          <div className="post-image">
            <img className='post-img' src={postimage}></img>
          </div>
        </div>
        <div className="post-box-action">
          <div className="upvote">
            <button className='action-upvote' onClick={() => setvote(vote + 1)}>
              <svg className='upvote-icon' width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 4 3 15h6v5h6v-5h6z" class="icon_svg-stroke icon_svg-fill" stroke-width="1.5" stroke="blue" fill="none" stroke-linejoin="round"></path></svg>
            </button>
            <span className='upvote-text'>Upvote</span>
            <span className='dot-post-action'></span>
            <span className='upvote-count'>{vote}</span>
            <span className='border-post-action'> </span>
            <button className='action-downvote' title='Downvote' onClick={() => setvote(vote - 1)}>
              <svg className='downvote-icon' width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m12 20 9-11h-6V4H9v5H3z" class="icon_svg-stroke icon_svg-fill" stroke="#666" fill="none" stroke-width="1.5" stroke-linejoin="round"></path></svg>
            </button>
          </div>
          <div className="comment">
            <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12.071 18.86c4.103 0 7.429-3.102 7.429-6.93C19.5 8.103 16.174 5 12.071 5s-7.429 3.103-7.429 6.93c0 1.291.379 2.5 1.037 3.534.32.501-1.551 3.058-1.112 3.467.46.429 3.236-1.295 3.803-.99 1.09.585 2.354.92 3.701.92Z" class="icon_svg-stroke icon_svg-fill" stroke="#666" stroke-width="1.5" fill="none"></path></svg>
            <span className='comment-text'>{comment}</span>
          </div>
          <div className="share">
            <svg width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><g class="icon_svg-stroke" stroke="#666" stroke-width="1.5" fill="none" fill-rule="evenodd" stroke-linecap="round"><path d="M19.748 10a8.003 8.003 0 0 0-15.496.002m.001 4.003a8.003 8.003 0 0 0 15.494 0"></path><path d="m2.5 7.697 1.197 3.289 3.289-1.197m14.5 6.5L20.289 13 17 14.197"></path></g></svg>
            <span className='share-text'>{share}</span>
          </div>
        </div>
      </div>
    </>
  )
}

export default Postcard
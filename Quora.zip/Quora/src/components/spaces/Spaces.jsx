import React from 'react';
import './spaces.css';
import { spaces } from '../../data/spacedata';
import Spacecard from '../space-card/Spacecard';


const Spaces = () => {
  return (
    <>
    <div className="spaces">
      <div className="space-header">
      <span className='space-title'>Spaces to follow</span>

      <div className='space-border'></div>
      </div>
      {
        spaces.map((data)=>{
          return <Spacecard 
          image={data.image}
          title={data.title}
          description={data.description}/>
        })
      }
    </div>
    </>
  )
}

export default Spaces
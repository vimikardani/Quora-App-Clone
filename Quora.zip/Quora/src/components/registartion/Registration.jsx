import React from 'react';
import { useState } from 'react';
import './registration.css';
import { useNavigate } from 'react-router-dom';


const Registration = () => {
  const [validatedata, setvalidatedata] = useState({email:'',password:'',confirmpassword:''})

  function handledata(event){
    setvalidatedata({email:event.target.value});
    console.log(validatedata);
  }
  function handledata1(event){
    setvalidatedata({password:event.target.value});
    console.log(validatedata);
  }
  function handledata2(event){
    if(event.handledata2!==event.handledata1){
     console.log('error');
    }
    return;
  }

  // page redirect to login page
    const navigate=useNavigate();

    const openSigninpage=()=>{
      if(validatedata.email==""&&validatedata.password=="" &&validatedata.confirmpassword==''){
        alert('please fill all the fields')
      }
      else{
        navigate('/Login')
      }
      
    }


  return (
    // Registration page UI
    <>
    <div className="login-bg">
    </div>
    <form>
    <div class="register-form">
    
    <img className='quora-regi-logo' src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Quora_logo_2015.svg/250px-Quora_logo_2015.svg.png" alt="Logo" />
    <br></br><br></br>
    <h1>Register</h1>
    <p>Please fill in this form to create an account.</p>
    <hr></hr>

    <label for="email"><b>Email</b></label>
    <input className='regi-input' type="text" placeholder="Enter Email" name="email" id="email" value={validatedata.email} onChange={handledata}/>

    <label for="psw"><b>Password</b></label>
    <input className='regi-input' type="password" placeholder="Enter Password" name="psw" id="psw" value={validatedata.password} onChange={handledata1}/>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input className='regi-input' type="password" placeholder="Repeat Password" name="psw-repeat" id="psw-repeat" value={validatedata.confirmpassword} onChange={handledata2}/>
    <hr></hr>
    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>

    <button  class="registerbtn" onClick={openSigninpage}>Register</button>
  </div>
  
  <div class="container signin">
    <p>Already have an account? <a href="#">Sign in</a>.</p>
  </div>
</form>

    </>
  )
}

export default Registration
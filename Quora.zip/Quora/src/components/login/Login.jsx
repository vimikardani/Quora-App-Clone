import React from 'react';
import { useState } from 'react';
import './login.css';
import { useNavigate } from 'react-router-dom';


const Login = () => {
  const [validateinput, setvalidateinput] = useState({
    email: "", password:""
  })

  function handlechange(event){
    setvalidateinput({email:event.target.value});
    console.log(validateinput);
  }
  function handlechange1(event){
    setvalidateinput({password:event.target.value});
    console.log(validateinput);
  }


  const navigate = useNavigate();
  const handleClick = () => {
    // Redirect to the registration page
    navigate('/registration');
  };
  // Redirect to the Home page
  const openHomepage = () => {
    if(validateinput.email==""&&validateinput.password==""){
      alert('please fill username and password fields')
    }
    else{
      navigate('/')
    }
    

  }
  return (
    <>
    {/* for Login page background */}
      <div className="login-bg">
      </div>

      {/* Login Form page UI */}
      <div className="login-page">
        <div className="quora-logo">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/91/Quora_logo_2015.svg/250px-Quora_logo_2015.svg.png" alt="Logo" />
          <br></br>
          <span className='login-title'>A place to share knowledge and better understand the world</span>
        </div>

        <form class="login-form" action=''>
          <div class="imgcontainer">
            <img className='login-user-image' src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABRFBMVEXt5/X////t7e3u7u7+GEZ5VUf/qUTr6+vwjTxNNC93Rxn/q0Tt5vZwUEfSjEXu6PZdQTlzTDv+ADHz7/7+ADa+rrM8LC//rkTh2ObmiDz+AEb+AD3u6/B2UEF1U0d1UDzr8f/18/r+ADv6+f3t6fJvRjOehYH7okJFNS6EYld/W03blEWKX0izekbxoUXCg0idbEdrPRQ5JS1kRDHwvdDs+Pb5W3b+hZfxwMvXy9TMv8jEtLumkJCOb2i0oaPo3u2umZnEgDO1dS7PhjXckjmLbGKHUR+VXSOnaSiVeHFKNDaIWzWydjqXYzcvIy71lj8+NiwqLC2SLDjHIj3xhD3ZHkFuLzL/dET+T0WGOjtxX0/yr8T8Ml3YLEXoRGD6RGn2aYf0mbH3c47uy979OUX+b0X7PmP7xND8s8D72uLv3uL/n61MoYQXAAAPTklEQVR4nO2d63/SyBrH00JxkdQRQk0FqlCg1FvPqStgbRUv9bqXulrXntPuqbdd2/r/vz8zJEACzyTPM5kA1T4vdD6mhfk6z+U3k8nEmBE2m0gkZr/TljEl/TgjPCMMJeR27jttGaLpwJ77PltGYuJuFG8rcUZ46lsJYxCS577L1qwx8S7E3fph6uHE+3FGGJlw4sojvtaZpjn1rR+h4o+XsMTt3JgJByEZi6Lgf1ertRpjhmGYpml0TfzNGKvVqtUZb1I4hZqmWqkZLpXE+NVKNcYexFgPZ0sWE2MVDOgwmkalNHu6Kn6phmHzYZpGrXRaCKs1Gl0Pkv9OrRoboSYdkUiUKqYKXp/SrJV416ZX01SYqY7nQhqsMq2apht8WsyslKaw4peUgk+GaBqlKSMsMW10PWN6UqseTVONHn4gow4poEPTlGKA61lpGjRNLUZAw6xF7l9Uwkoc7uljrEyWkMUNyI1NTNMkErEPoGNmJTEhTaOtwociMqX+RdU0YxpAl7Ey/oo/jgj0ItbGTFgaM6Dw1HFqmkScRV5GyGePCYWyr6ZpxhqCHquMS9PEqmKCTCkY6YQJ/dMIvCkEI51wgnxuvolZ04w9iQ5br5zHpWkmDmgacWqaczMaVyrULc6KP/ERdCw+wqkYQWExaZrpARTpJg5NE7EOMscs11ikj6vFoWkiKJkul7G4cW9zc3Ohb1EQCeoGS5ioqNOxjYWt+3P1ej3rtfoDKwKiUcEmECyh2nye4y0uvMzWs1eX5kasvhhpFLEL/1hNo8RndRau1bMAnGPXIg2iqVfTKBRCZm2sBOBxy0bzUxbSZ5KmoWcZzveyHoQX3U9FQtVV8ekzXquzEso3N7d0zepWEEVCs6KNkArIrAUEn/DTrc17G4uGcnXUpGlmqd/OOvezGD4xiqJsZK+vLCwqQbJEeO8RmoZaCa2NwPwCg9avPehYdMZKaO8x9ZDoo9xDiXyOXa2vLJIZzWpY7xGExC+1HqoBipGsbxnE+tFd749ISMujzFrBhiBk2aV7VMRKZE1D81FrKwogt/qWRftGM6qmodX6CC7aH8b7BikuzFo0TUNbvldNMj5buk5EjFbxSYBsQwOgQOzQslsUwioJsLNErYMyRNIodiuGqqYh/V9aL/UAcsT7lIw6uENM1zQlSlqzFiKmUY9lt0iIJWVNQ5kVssW6NkBeNO6R3Ee14pMSqT4f7VqWFIpB2/yCCCmA7F5dJ+Dc0grBT02mpmlIQ8iuq3BcmZde4n6KjxEz4H5UgKahLK8ppZkr87fW5IjXCfLNtJQ0DSXNMHoQXpn/95qduSFFzC5Q8qlCxSctAVsPyEM4f/OGnUql7FtSxCUTn2xM6QJxACEhl5nkIZyfu2BnUsLsm1ckP5NdIEQikxPKNA2l2rNN2hBemf9XJuMAcpOHIiXXlMiahjLzta7R+G6l+niplDwUs5sUN5VwyOshZQgpcwonwaQ8Jg3FJdKyf0g9HLlCmVVYK/gwnL+5baf8lpGGYn2DMIiyNSkZIaEYMgM9hIME40OUVcUligCvBROOaAH8JxsMW+27CWaET/ipLBSzlIQOckg1DUWxWfdRTioSjJ0CCaWhmKVMMUokTUNx0k4dxccTDEgXVBVJ+rtGqviUTIpxUiDBoEKR4qYGhZByyxfhpHCC8SPCoUhy01mCpiFNnOohfDzBhPFJQ5GUTcFHiCSahiBo2L1gJx1SMNRQvE4gtAiahuAa1laQk44qGGIo1hfxXWGEio//VMMKmtyHJRg/IhSKJG2KJ6wSnDRgiQ2RYPx+emvUT0n1ogqlTUjTzBImv/KJk1TByAfxAjCIlECsoDUNod7LwtBJMBoI64SbGDW0piFss5RMDYMVDIWQVBHRFZ+ymA85qbsG4/Y7wFf912BCwsYpE0tImBuCk19e4fudttcePX4k8dZMg19bywQT0lINUtNQCCFROn+h32v70fr6+fX1JxBi5kn32iM7kJCUaqpITUO4sw0mmgEhhzgvbH0bmPduu9ceZQIJ6/jeGNByFBScFMKnQYSZzHnXno3mHftZ72IIIWEpA9pzChFSNBtUKwZjuLbuQqwDXtq/thZISFA1JtNOCCuaAeF2n6Ix4qSN/rXtYMIHhP7gNA3hrhq8juiJwx7FecBLzw+PL0xISKamgdQ0BFUKzu8HcWg/Hs4mnkF85F57bAcTPiUkU6SmISiah4GEvNPPBcb6C0jg2C+6155ngjPN3Byx5CMqPoEQXAv2EmaePH/2QjKFsrdfPHv+ZDD9kBASbnjHQPgU6pKHUDDaUtk2dE1CSNgNDhICmoZACHqVj5BgMkJ8QTRxmga/DMXM+hgIKdN8YGcNUA8JhPAEXzch4QmpEqriEwg3wAm+bkLC/Ek3oQmvJGompKyZygl9WgD9eZJFGt2EhBniOZSmwa+0SbZg6CZ8iSfUrWnYQ3AZSjchXrZpr/iShTbdhPjb+VhC7OfJbuBrJiSsY2A1DZ4Q3nGpm3CJRohYp0EXWFiWaifMoh8WYsh1GjyhZDlYNyH6sTbtqxiS+07aCbH9AQ9biLTWBk8tJkhYQ957whNeBXt05Rb9noUAhO6uCatj76OYNeQ6DXrN25LcWXsFLAAjCLdfwR+HXxOu+jjkmgZNyCSEF9NKhOmL8MddxUoQ6OmZSPeeGHjjSRC++oXup/Yvr2DCq/hVDCCpwITIz5NM8cUYXvqVimj/ehscwyUCIEwI7adBRnYAYfo2MZ/aF26nQUIOiNbJtSEOqaaZRW6nkW675ITp2zcouxTsGxwQIqSMoPc+fsh+GmyqYSswoiDko4h31O4IQoQkwMC9GENXsH5hbYJnJ3QJ07eRsZjpxiBISAMk7KfB74myFq8D+dQhTN/+DYdo/+YAjhASAeHHSuA9wvh9bQzyVJcw/ernNdmeWc8Qrv18KQ0RkrKosAphjzBhbyLjniojTPOqEQroeugoIRXQKFH2CJMeHh3x1AFh+vfLjaCdUZnG5d/TICF5BAcPsCEqPu1oNnPEUz2Ely7/tNOQ3plp7Px0+RJMSAak7REmHnw17Kl+Qm6N0WjkI9sQlySECoCyfd5QkaTt1Rfm99QRQgHpHUlOt7Pj/DtMqADIw5D03BP1432eChEK29lpCOvByQlVAA2QQ8szMy6ix1NlhJBBhEqAIc/MjFwhnabgGPfUJR2E9CwqjPzcE/n0K29OjUaoBBj67NqoFlA5RpC5h5v0CFdfv/4jlPCP16urHkK1ERTPOsMc8me51Y5dd3LqRQcv/ebtX293Qwh3+c+8WX292iOkzAe9hDIO+bPcisd2dz31Ynp1dfXNuyS3QihhQfzYOw4pCBVH0NnRRqr43BSP8xQ59eLrP98mHSu8bwQCNt4X3J98++fri6ojqPQsN/2kvZ6VF53hc2zP3gkA3LH3Bj/67j//VT5IEUwyQZpmlnimwsBYef+gmPSYnQogTNneH/3rf3fKak5aUzqfhnQ6TZ/vzkHe2+lkoZGR+ynX3gXfT+cOP5dVCD2phXI+Df1Mz3KnlUv6rfDeldhQEKbs937CZDH3oaPAKAm0MEJqwWDlj/lictj2+DQfDkWuxb1h2GNc3qe6qql6Pg2xYFidw/xIf7uBmAERd/hkwy4Av5BrdYgn78mSpYcQ0ALUql/eXx4dQOGmu5wEQBSAmV2IMFlM3ikTvlncclI9c4+ww7rcHo5Aj5uK6fyoi6YgJ3WH8SMeMeRtUCHntWHTKWMt0EO7g+hMff2IDWeeDw6hsPwH/EmfIee1BRLi79EcLMv6yrOpu2w68NQdZ1UjM5xJPbZ8iL57H5RKQglxNZF1kmAI9sweLDx1+XoLGnbQLxUPcCfwhJ6bKNM0bgtTEzlgoHVzTW99pjFYlZLkmQEiaoN3Leo5wghA8yCYsD+IQxY4hF1EhtDhkc8RDl3gZ+V/Al006YlEP2BAFLqIh+VQwkpg7zGEoRWj/EGeZPqIo4vCXAWEAfKM+qkc9v8b0nsNZ0GXP8rqoNe+AE8FfUH8XmhdRJ8FDWua8BOjTPYZA5gs7A0hZuy98CEUiJ8DfagS2nvMuxEC5akVmmVARCxgMnkQNIjdM9mDe497N4J8EMvt8CB0Eb80PE8HN74gAZP5jwGnC4Y4KKbiOy2pnyJ91GX827btTCbD//gby5cM8lON70aQLmiUD8MKhQ+xsPd+d3f3/V6BAChKhoQQ+X6LEE3jtuDKy/YJQ+hCCqP9Tu4OPIgspM9YTeO24CFEppmI9g88509ghobwriAtQ6hm4CBS3xUU7s5AtikfjgUwWWyVRwm1v+8JeGcXKZFGstF0Sn9nV6AqcFvD31L+REmkUazYHh7EGrLPM7R3WA4hWuMC5DY8x0jE8w7LWd8eFHZnXE7KhY0v15jiFY/IPlPfYTkZJxVu6llApb2/mvpebs/3lMfGJ2wQiJINelE1Td+7J5BJhQ2yqVgdDe+pgqbptfqHZrB97KxCh+X3+4GIh6NpmkFrAmHIA7G/nEFIMtSK3285Krz8zxgBhTbtumiNljYUCR11Ux6nkyaTy5ZT6Gk99RAi9YHb4hqVdcaZaHiq6TDn7VW0ns7Q38vdbSVKJrsjvRMTi4maXyIomUGLWA/7LWt/vITL+5ZaT6kVf9A6GrOX7iuEYDTCma/wLd9YrLj8ldy/PiFF0/hb1ZF9F3FZrlVV6J+ipvG0Es0jYOuFfivmj5rINRk9msbbqoxhGHOtyoxyKEUm5NFYiLfyLxe+RupfdMKZmXaMrlrMtSP3T0nT+FrNkw+5mBhzrZNm5P4paZrh1nErBsZi7vA4Uq8iapqh1t1DzYyc727kXkWs+L5WonlX5zgWc63jZmKqCHmredLO69Gqy/n2SVNTryJpGmAV5+gg8kAWcwdH3kQRuVcRNM1oK9Fsfm4XI1SP5XyxfbfZTOiB06FpAKfgIuBTUWkki/nlT7y8awsbbRUfTK3tgxxp6lHM5w7aepLneAi5u54ctQu5PAKzuJzPJdtHIrfESRhBM0haor/Vr99ahZzgBEEFWy7Z+va1KnxTew90ahrpek5CiK7jo2/t1gEn5ZYX1m0kD1rtb1+FahGFIa4e6NM0oU7bbM5UT46P7wo7Pj6pzoh/isctY6v4OFYn3Y7p2yZBOP6WTk0znS29mmYqW/HUw2lqnRGe/lZsmmZqWrFqmqlo/QD18IzwtLfONM130Pph6uHE+3FGGJVwkFC/v9b/AUHTycGU5c5PAAAAAElFTkSuQmCC" />
          </div>
          <div class="container">
            <label for="uname"><b>Username</b></label>
            <input className='input' type="text" placeholder="Enter Username" name="uname" value={validateinput.email}  onChange={handlechange}/>

            <label for="psw"><b>Password</b></label>
            <input className='input' type="password" placeholder="Enter Password" name="psw" value={validateinput.password}  onChange={handlechange1}/>

            <button type='submit' className='signin-btn' onClick={openHomepage} >Sign In </button>
            <button  className='signup-btn' onClick={handleClick} >Sign Up</button>
            <label>
              <input type="checkbox" checked="checked" name="remember" /> Remember me
            </label>
          </div>
          <span class="psw">Forgot <a href="#">password?</a></span>

        </form>
      </div>
    </>
  )
}

export default Login
import React from 'react';
import { useState } from "react";
import './notification.css';
import Navbar from '../navbar/Navbar';
import Postmodal from '../postmodal/Postmodal';
import { notifications } from '../../data/notificationdata';
import Notificationcard from '../notification-card/Notificationcard';


const Notification = () => {
  // open addquestion modal
  const [showmodal, setshowmodal] = useState(false);

  return (
    <>
    
      {
        showmodal ? <Postmodal showmodal={showmodal} setshowmodal={setshowmodal} /> : ""
      }
      {/* add Navbar component in this page */}
      <Navbar showmodal={showmodal} setshowmodal={setshowmodal} />

      {/* Navbar UI */}
      <div className='main'>
        <div className="sidebar">
          <div className="filters">
            <span className='filter-title'>Filters</span>
            <div className='filter-border'></div>
          </div>
          <div className="notification-option">
            <button className='allnotification-button'>All Notifications</button>
            <button className='notification-button'>Stories</button>
            <button className='notification-button'>Questions</button>
            <button className='notification-button count'>Spaces
              <span className='notication-count'>3</span></button>
            <button className='notification-button'>People updates</button>
            <button className='notification-button'>Comments and<span>mentions</span></button><br></br>
            <button className='notification-button'>Upvotes</button>
            <button className='notification-button'>Your Content</button>
            <button className='notification-button count'>Your profile
              <span className='notication-count'>1</span></button>
            <button className='notification-button count'>Announcements
              <span className='notication-count'>5</span></button>
            <button className='notification-button'>Earnings</button>
            <button className='notification-button'>Subscriptions</button>
          </div>

        </div>
        <div className="notifications">
          <div className="notification-header">
            <div className='notification-title'>Notifications</div>
            <div className="left-text">
              <button className='mark'>Mark All As read</button>
              <span className='noti-dot'></span>
              <span className='noti-settings'>Settings</span>
            </div>
          </div>
          <div className="notification-border"></div>

          {/* Map all notification data from notificationcard components */}
          {
            notifications.map((data) => {
              return <Notificationcard
                notificationimage={data.notificationimage}
                notificationtitle={data.notificationtitle}
                releasedate={data.releasedate}
                info={data.info} />
            })
          }

        </div>
      </div>
    </>
  )
}

export default Notification
import React from 'react';
import './addquestion.css'

const Addquestion = () => {
  return (
    // add question modal UI
    <>
      <div className="question-box">
        <div className="profile-detail">
          <img className='profile-image' src='https://qph.cf2.quoracdn.net/main-thumb-2347017531-200-yleabagnsyatqshhbwivicyhkhwlxfaz.jpeg'></img>
          <svg className='left-arrow addque-icon' width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m18.5 12-11 7V5z" class="icon_svg-stroke icon_svg-fill" stroke-width="1.5" stroke="#666" fill="gray" stroke-linecap="round" stroke-linejoin="round"></path></svg>
          <button className='btn-public'>
            <svg className='addque-icon' width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><g class="icon_svg-stroke" transform="translate(4 4)" stroke="#666" stroke-width="1.5" fill="none" fill-rule="evenodd"><path d="M10 15.5a5 5 0 0 0-10 0m17 0a5 5 0 0 0-7.032-4.57"></path><circle cx="5" cy="4" r="4"></circle><path d="M9.678 7.258A4 4 0 1 0 9.791.665"></path></g></svg>
            <span>Public</span>
            <svg  className='addque-icon' width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m5 8.5 7 7 7.005-7" class="icon_svg-stroke" stroke="#666" stroke-width="1.5" fill="none" stroke-linecap="round"></path></svg>
          </button>
        </div>
        <div className="question-detail">
        <input type='text' className='question-info' placeholder='Start your question with "What","How","Why",etc.'/> 
        <div className='addquestion-border'></div>
        <p className='question'></p>
        </div>
        <div className="question-footer">
          <div className="question-footer-border"></div>
          <div className="buttons">
          <button className="cancle-btn">Cancel</button>
          <button className="addquestion-btn">Add Question</button>
          </div>
        </div>

      </div>
    </>

  )
}

export default Addquestion
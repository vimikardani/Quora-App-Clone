import { useState } from "react";
import React from 'react';
import Navbar from "../navbar/Navbar";
import Sidebar from '../sidebar/Sidebar';
import Post from '../post/Post';
import Postmodal from "../postmodal/Postmodal";
import Spaces from '../spaces/Spaces';
import './main.css'



const Main = () => {
  // open addquestion modal using usestate
  const [showmodal, setshowmodal] = useState(false)
  return (
    <>
    {/* open add question modal*/}
    {
      showmodal?<Postmodal showmodal={showmodal} setshowmodal={setshowmodal}/>:""
    }
    {/* add commonents in main file */}
    
    <div className='main-container'>
    <Navbar showmodal={showmodal} setshowmodal={setshowmodal}/>
    <Sidebar/>
    <Post/>
    <Spaces/>
    </div>
    

    </>
  )
}

export default Main